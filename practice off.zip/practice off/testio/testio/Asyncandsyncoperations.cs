﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Threading.Tasks;
using System.Text;

namespace testio
{
    class Asyncandsyncoperations
    {
        public static void Main()
        {
            Work1();
            Work2();
            Console.WriteLine("start Main....");

            Task<double> t = BigCalculation();
            Console.WriteLine("start End....");
            var x = t.Result;
            Console.WriteLine("Result:{0}", +x);
            Console.ReadLine();
        }


        static async void work1() {
            console.writeline("work1.....long operation bigns");
            awaite Task.Run(() => {
                Console.WriteLine("................");
                Task.Delay(5000).Wait();
            
            });
           
        }

                 

    static async void work2();
        {
        console.writeline("work2.....long operation bigns");
            awaite Task.Run(()=>{
            Console.WriteLine("................");
            Task.Delay(5000).Wait();
        });
 }




    static async Task<double> BigCalulation()
                {
                    double sum = 0;
                    Console.WriteLine("Big caluculation....operation bigins");
                    IEnumerable<int> mynumber = Enumerable.Range(1, 100000000);
                    await Task<double>.Run(() =>
                    {
                        foreach (int i in mynumber)
                            sum += i;
                    });
                    Console.WriteLine("bigcaluculatiomn end")
                                        return sum;
}