﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;


namespace FileInputOutput
{
    class TestIOMain
    {
        static void Main(string[] args)
        {
            new TestIOMain();
        }
        public TestIOMain()
        {
            FileStream fs = null;
            string name = "";
            string email = "";
            Supplier s1;
            BinaryFormatter bf = null;
            try
            {
                fs = new FileStream("objs.txt", FileMode.OpenOrCreate);
                sf = new SoapFormatter();
                
                while (fs.Position<fs.Length)

                {
                    s1= (Supplier)sf.Deserialize(fs);
                    if(s1!=null)
                    {
                        Console.WriteLine("Name:{0}-----Email:{1}", s1.SupplierName, s1.SupplierEmail);
                    }
                   
            }
            Console.WriteLine("enter your Name:")
}
