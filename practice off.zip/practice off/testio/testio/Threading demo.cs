﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    class Threading
    {
        static void Main(string[] args)
        {
            new Threading();

        }
        Thread th1, th2;
        int[] resource = new int[] { 10, 20, 30, 40, 50 };


        public Threading()
        {
            Console.WriteLine("Main Thread Starts......");

            th1 = new Thread(task1);
            th2 = new Thread(task2);
            //task1();
            //task2();
            th1.Start();
            th2.Start();
            Console.WriteLine("Main Thread Ends......");
        }
        public void task1()
        {
            Console.WriteLine("Task 1 Starts......");
            int sum = 0;
            Console.WriteLine("Reading data task1 .....");
            for (int i = 0; i < resource.Length; i++)
            {
                Console.WriteLine(resource[i] + "\t");
            }
            for (int i = 0; i < resource.Length; i++)
            {
                sum += resource[i];
                Thread.Sleep(1000);
            }
            Console.WriteLine("Task 1 Result : {0} ", sum);
            Console.WriteLine("Task 1 Ends......");

        }
        public void task2()
        {

            Console.WriteLine("Task 2 Starts......");
            int mul = 1;
            Console.WriteLine("Reading data task 2.....");
            for (int i = 0; i < resource.Length; i++)
            {
                Console.WriteLine(resource[i] + "\t");
            }
            for (int i = 0; i < resource.Length; i++)
            {
                //resource[i] = mul * i;
                mul *= resource[i];
                Thread.Sleep(1000);
            }
            Console.WriteLine("Task 2 Result : {0} ", mul);
            Console.WriteLine("Task 2 Ends......");
        }
    }
}