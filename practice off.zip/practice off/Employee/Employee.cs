﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeAssignment
{
    class Employee
    {
        public static int idCtr = 100;
        public int EmployeeID { set; get; }
        public string EmployeeName { set; get; }
        public DateTime EmployeeDob { set; get; }
        public int EmployeeSalary { set; get; }
        public Employee()
        {
            EmployeeID = ++idCtr;
        }
        public Employee(string name, DateTime dob, int salary)
        {
            EmployeeID = ++idCtr;
            EmployeeName = name;
            EmployeeDob = dob;
            EmployeeSalary = salary;

        }
        public void Display()
        {
            for (long i = 0; i < 1000000000; i++)
            {

            }
            Console.WriteLine("----------------------------------------------------------------------------------------------");
            int age = DateTime.Now.Year - this.EmployeeDob.Year;
            double tax = 0;
            if (age < 18)
                tax = 0.02 * this.EmployeeSalary;
            else if (age >= 18 && age< 40)
                tax = 0.15 * this.EmployeeSalary;
            else if (age >= 40 && age < 80)
                tax = 0.20 * this.EmployeeSalary;
            else if (age >80)
                tax = 0.25 * this.EmployeeSalary;
            Console.WriteLine(this.EmployeeID+"\t"+this.EmployeeName+ "\t" + this.EmployeeDob + "\t" + age+ "\t" + this.EmployeeSalary+ "\t\t" + tax+ "\t\t" + (this.EmployeeSalary-tax));
        }

        

    }
}
