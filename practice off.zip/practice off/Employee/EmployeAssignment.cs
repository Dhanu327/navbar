﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeAssignment
{
    class EmployeAssignment
    {
        static void Main(string[] args)
        {
            List<Employee> list = new List<Employee>
            {
                new Employee{EmployeeName = "Subh",EmployeeDob = DateTime.Parse("10/08/1996"),EmployeeSalary = 25000},
                new Employee{EmployeeName = "Subham",EmployeeDob = DateTime.Parse("22/10/1993"),EmployeeSalary = 50000},
                new Employee{EmployeeName = "Pinku",EmployeeDob = DateTime.Parse("14/02/1999"),EmployeeSalary = 65852},
                new Employee{EmployeeName = "Subha",EmployeeDob = DateTime.Parse("23/11/1998"),EmployeeSalary = 24851},
                new Employee{EmployeeName = "Su",EmployeeDob = DateTime.Parse("13/02/1997"),EmployeeSalary = 58421},
                new Employee{EmployeeName = "Kunu",EmployeeDob = DateTime.Parse("29/08/1998"),EmployeeSalary = 32547},
                new Employee{EmployeeName = "Shibu",EmployeeDob = DateTime.Parse("17/10/1996"),EmployeeSalary = 21475},
                new Employee{EmployeeName = "Baina",EmployeeDob = DateTime.Parse("12/03/1995"),EmployeeSalary = 52000},
                new Employee{EmployeeName = "Sourav",EmployeeDob = DateTime.Parse("08/10/1991"),EmployeeSalary = 32145},
                new Employee{EmployeeName = "Sandeep",EmployeeDob = DateTime.Parse("01/05/1992"),EmployeeSalary = 12345}
            };
            Console.WriteLine("--------Employee Console----------");
            Console.WriteLine("\nNormal For Each.\n");
            Console.WriteLine("EmpID\tEmpName\t\tEmpDob\t\tEmpAge\tEmpSalary\tEmpTax\t\tEmpNetSalary");
            DateTime startTime = DateTime.Now;
            foreach(Employee e in list)
            {
                Console.WriteLine("----------------------------------------------------------------------------------------------");
                e.Display();
            }
            DateTime endTime = DateTime.Now;
            TimeSpan ts = endTime - startTime;
            Console.WriteLine("\nExecution Completed in Normal Foreach Duration : {0}",ts.TotalMilliseconds);

            Console.WriteLine("\nParallel For Each.");
            Console.WriteLine("EmpID\tEmpName\t\tEmpDob\t\tEmpAge\tEmpSalary\tEmpTax\t\tEmpNetSalary");
            startTime = DateTime.Now;
            Parallel.ForEach(list, (e) =>
            {

                
                e.Display();

            });
            
            endTime = DateTime.Now;
            ts = endTime - startTime;
            Console.WriteLine("\nExecution Completed Parallel Foreach in Duration : {0}", ts.TotalMilliseconds);
        }
    }
}
