﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnDemo.Repositories
{
    class Service1:IService1
    {
        public void Task()
        {
            Console.WriteLine("Service 1 Task1 Running.");
        }
    }
}
