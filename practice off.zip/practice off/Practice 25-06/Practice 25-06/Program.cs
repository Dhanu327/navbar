﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_25_06
{
    class CollectionTest
    {
        static void Main(string[] args)
        {
            new CollectionTest();

        }
        List<items> cartItems = new List<itmes>();
        Dictionary<string, items> cartItems = new Dictionary<string, items>();
        public CollectionTest()
        {
            string ans = "y";
            do
            {
                Console.WriteLine("Insert cart item:");
                Console.WriteLine("search cart item:");
                Console.WriteLine("Display cart item:");
                Console.WriteLine("Enter Your choice:");
                int choice = int.parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Insertcart();
                        break;
                    case 2:
                        Searchcart();
                        break;
                    case 3:
                         Displaycart();
                        break;

                }
                Console.Write("do you want continue(y/n)");
                ans = Console.ReadLine();
                while (ans == y) ;

            }
            public void Insertcart();
            {
                Console.Write("Enter the cart item:");
                string name = Console.ReadLine();
                Console.Write("Enter item value:");
                int cost = Console.ReadLine();

            }
            public  void Searchcart();
            {
                return cartItems[name];
                return cartItems[cost]
            }
            public void Displaycart();

            {
                var ie = cartItems.getEnumerator();
                while(ie.MoveNext())
                {
                    Console.WriteLine("key:{0}-------value:{1}", ie.key, ie.cuurent.value);
                }
            }
        }

    }
}
