﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileInputOutput
{
    class TestIO
    {
        static void Main(string[] args)
        {
            new TestIO();
        }
        public TestIO()
        {
            FileStream fs = null;
            try
            {
                fs = new FileStream("a.txt", FileMode.OpenOrCreate | FileMode.Append);
                Console.WriteLine("Enter Your Name : ");
                int i = Console.Read();
                while (i != 13)
                {
                    fs.WriteByte((byte)i);
                    Console.WriteLine(i);
                    i = Console.Read();
                }
                fs.Close();
            }
            catch (FileNotFoundException nt)
            {
                Console.WriteLine(nt.Message);
            }
            finally
            {
                if (fs != null)
                    fs.Close();

            }


        }
    }
}