﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice_2
{
    
    public class Program
    {
        static void Main(string[] args)
        {
            int table = 2;
            int length = 10;
            int i = 1;

            Console.WriteLine("Multiplication table: " + table);
            for (i = 1; i <= length; i++)
                Console.WriteLine("{0, 2} * {1, 2} = {2}", i, table, table * i);
            Console.ReadLine();
        }
    }
}
