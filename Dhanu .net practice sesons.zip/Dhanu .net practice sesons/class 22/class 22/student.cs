﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class_22
{
    class student
    {
        public string Name;
        public string Email;
        private int age;


       /* public void SetAge(int age)
        {
            if (age >= 18 && age <= 70)
                Age = age;
            else
                Age = -1;
        }
        public int GetAge()
        {

            return Age;
        }*/
       public int Age
        {
            set
            {
                if (value >= 18 && value<= 70)
                    age = value;
                else
                    age = -1;

            }
            get
            {
                return age;
            }
        }
    }
}
