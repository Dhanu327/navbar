﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class_22
{
    class Program
    {
        static void Main(string[] args)
        {
            student s1 = new student();
            s1.Name = "Rajesh";
            s1.Email = "rajesh.23@gmail.com";
            s1.Age = 18;



            Console.WriteLine("Name:{0}", s1.Name);
            Console.WriteLine("Email:{0}", s1.Email);
            if (s1.Age() == -1)
                Console.WriteLine("invalid Age");
            else
                Console.WriteLine("Age:{0}", s1.Age());


            Console.WriteLine("Age:{0}", s1.Age);


           


            Console.ReadLine();
        }
    }
}
