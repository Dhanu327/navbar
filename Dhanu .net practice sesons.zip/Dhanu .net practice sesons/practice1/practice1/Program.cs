﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value of 1 st number");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the value of 2 nd number");
            int y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter your operation");
            String op = Console.ReadLine();
            switch(op)
            {
                case "+":
                    Console.WriteLine(x + y);
                    break;
            }



        }
    }
}
