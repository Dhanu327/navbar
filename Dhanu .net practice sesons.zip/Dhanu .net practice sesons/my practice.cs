using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myExDll
{
   
    public class ReverseString
    {
        public static void Main()
        {
            string Orginalstring = Console.ReadLine();
            string ReverseString = string.Empty;
            for (int i = Orginalstring.Length - 1; i >= 0; i--)
            {
                ReverseString += Orginalstring[i];
            }
            Console.Write($"ReverseString is : {ReverseString} ");
            Console.ReadLine();
        }

    }

    public class Demo
    {
        public static void Main()
        {
            string myStr;
            int i, len, vowel_count, cons_count;
            myStr = "Avengers";
            vowel_count = 0;
            cons_count = 0;
            // find length
            len = myStr.Length;
            for (i = 0; i < len; i++)
            {
                if (myStr[i] == 'a' || myStr[i] == 'e' || myStr[i] == 'i' || myStr[i] == 'o' || myStr[i] == 'u' || myStr[i] == 'A' || myStr[i] == 'E' || myStr[i] == 'I' || myStr[i] == 'O' || myStr[i] == 'U')
                {
                    vowel_count++;
                }
                else
                {
                    cons_count++;
                }
            }
            Console.Write("\nVowels in the string: {0}\n", vowel_count);
                
            }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int table = 2;
            int length = 10;
            int i = 1;

            Console.WriteLine("Multiplication table: " + table);
            for (i = 1; i <= length; i++)
                Console.WriteLine("{0, 2} * {1, 2} = {2}", i, table, i * table);
        }
    }