﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionTest1
{
    class Program
    {
        //Non Generic
        ArrayList a1 = new ArrayList();
        //Generic
        //List<int> a1 = new List<int>();
        //Hashtable ht = new Hashtable();
        //Stack st = new Stack();
        //Queue qt = new Queue();
        //Queue<int> qt1 = new Queue<int>();
        //Dictionary<int, string> dt=new Dictionary<int,string>();

        static void Main(string[] args)
        {
            new Program();
        }
        List<Customer> cus = new List<Customer>();
        Customer c = null;
        public Program()
        {
            string ans = "y";
            do
            {
                Console.WriteLine("1.Insert Customer");
                Console.WriteLine("2.Update Customer Email");
                Console.WriteLine("3.Remove Customer");
                Console.WriteLine("4.Sort Customer");
                Console.WriteLine("5.Search Customer");
                Console.WriteLine("6.View all Customer");
                Console.WriteLine("Enter a choice");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        InsertCustomer();
                        break;
                    case 2:
                        UpdateEmail();
                        break;
                    case 3:
                        RemoveCustomer();
                        break;
                    case 4:
                        SortCustomer();
                        break;
                    case 5:
                        Console.WriteLine("Enter Customer Name:");
                        string name = Console.ReadLine();
                        SearchCustomer(name);
                        break;
                    case 6:
                        DisplayCustomers();
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        break;
                }
                Console.WriteLine("Do you wany to continue(y/n)?");
                ans = Console.ReadLine();
            } while (ans == "y");

            Console.ReadLine();
        }
        public void InsertCustomer()
        {
            Console.WriteLine("Enter Customer Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Customer Email:");
            string email = Console.ReadLine();
            c = new Customer(name, email);
            cus.Add(c);
        }
        public Customer SearchCustomer(string name)
        {
            foreach (var w in cus)
            {
                if (w.CustomerName == name)
                    c = w;
            }
            return c;

        }

        public void UpdateEmail()
        {
            Console.WriteLine("Enter new Name:");
            string name = Console.ReadLine();
            c = SearchCustomer(name);
            if (c != null)
            {
                Console.WriteLine("Enter new Email:");
                string UpdatedEmail = Console.ReadLine();
                c.CustomerEmail = UpdatedEmail;
            }
            else
            {
                Console.WriteLine("No such Customer");
            }
        }
        public void RemoveCustomer()
        {
            Console.WriteLine("Enter new Name:");
            string name = Console.ReadLine();
            c = SearchCustomer(name);
            if (c != null)
            {
                cus.Remove(c);
            }
            else
            {
                Console.WriteLine("No such Customer");
            }
        }
        public void SortCustomer()
        {
            cus.Sort();
        }
        public void DisplayCustomers()
        {
            foreach (Customer q in cus)
            {
                Console.WriteLine(q);
            }
        }
        //ht.Add(1, "Raj");
        //ht.Add(2, "Raj");
        //ht.Add(3, "Raj");
        //ht.Add(4, "Raj");
        //foreach (var e in ht) {
        //    Console.WriteLine(ht[e]);
        //}

//a1.Add(1);
//a1.Add(2);
//a1.Add(3);
//a1.Add(4)
//a1.Add("Five");
//a1.Add(true);
//a1.Add('C');
//a1.Add(10.9);
//a1.Insert(4,45);
//Console.WriteLine("Elements of this arrays are:");
//for (int i = 0; i < a1.Count; i++) { Console.Write(a1[i]+" ");
}
}
}