﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace supplier_app
{
    class Storage_classs
    {
        private object[] date = new object[3];
        int count = 0;
        public void Addobject(object s)
        {
            if (count< data.length)
            {
                data[count] = s;
                count++
            }
        public object Getobject (int index)
            {
                if (index >= 0 && index < count)
                    return data[index];
                return null;

            }
            public int count()
            {
                return count;
            }
        }
    }

}
