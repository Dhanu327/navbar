﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace RegularExpression
{
    class RegularExpression
    {
        static void Main(string[] args)
        {
            new RegularExpression();
        }
        public RegularExpression()
        {
            string ans = "y";
            do
            {
                //Console.WriteLine("Enter Your ID :");
                //string ID = Console.ReadLine();
                //Match match = Regex.Match(ID, "^[0-9]{3,3}-[0-9]{8,8}$");
               // string email = Console.ReadLine();
               
                Console.WriteLine("Enter Your email :");
                string email = Console.ReadLine();
                Match mem = Regex.Match(email, "^[A-Za-z0-9]{0,1}+[Aa]+[A-Za-z0-9][@]+[A-Za-z0-9]+[.][a-z]{2,3}$");
                if (mem.Success)
                {
                    Console.WriteLine("Your email is : {0}", mem);
                }
                else
                    Console.WriteLine("Sorry!!");
                Console.Write("Do you want to continue?y/n : ");
                ans = Console.ReadLine();
            } while (ans == "y");


        }
    }
}