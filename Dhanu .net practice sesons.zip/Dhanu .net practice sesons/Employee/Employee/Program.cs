﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstApp
{
    class EmployeePro
    {
        private static int employeeId;
        static EmployeePro()
        {
            employeeId = 100;
        }
        public EmployeePro()
        {
            employeeId++;
            EmployeeID = employeeId;
        }
        public EmployeePro(string name, DateTime dob, double sal) : this()
        {
            Name = name;
            DOB = dob;
            Salary = sal;
        }




        public int EmployeeID { get; set; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public double Salary { get; set; }
        private double age;
        public double Age
        {
            set
            {
                TimeSpan ts = DateTime.Now - DOB;
                double d = (Math.Round(ts.TotalDays / 365.25));
                age = d;
            }
            get
            {
                return age;
            }
        }

        private double tax;
        private double netSal;

        public double Tax
        {
            set
            {
                if (age < 18)
                    tax = ((Salary * 10) / 100);
                else if (age >= 18 && age < 40)
                    tax = ((Salary * 15) / 100);
                else if (age >= 40 && age < 80)
                    tax = ((Salary * 20) / 100);
                else if(age>80)
                    tax = ((Salary * 12) / 100);
            }
            get
            {
                return tax;
            }
        }

        public double NetSalary
        {
            set
            {
                netSal = Salary - tax;
            }
            get
            {
                return netSal;
            }
        }

        public void Display()
        {
            Console.WriteLine("Details");
            Console.WriteLine("Employee Id: {0}", this.EmployeeID);
            Console.WriteLine("Employee Name: {0}", this.Name);
            Console.WriteLine("Employee DoB: {0}", this.DOB);
            Console.WriteLine("Employee Salary {0}", this.Salary);
            Console.WriteLine("Employee Tax: {0}", this.Tax);
            Console.WriteLine("Employee NetSalary: {0}", this.NetSalary);
            Console.WriteLine("Employee Age: {0}", this.Age);

        }




        public static void Main(string[] args)
        {
            List<EmployeePro> emp = new List<EmployeePro>();
            string name, ans = "y";
            DateTime dob;
            double sal;
            do
            {


                Console.WriteLine("Enter Details");
                Console.WriteLine("Employee Name:");
                name = Console.ReadLine();
                Console.WriteLine("Employee DoB: (dd/MM/yyyy): ");
                dob = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);

                Console.WriteLine("Employee Salary");
                sal = double.Parse(Console.ReadLine());
                EmployeePro e1 = new EmployeePro(name, dob, sal);
                emp.Add(e1);
                Console.WriteLine("Continue y/n");
                ans = Console.ReadLine();


            } while (ans == "y");
            //emp.Display(emp);

            foreach (var e in emp)
                e.Display();

            Console.ReadLine();



        }
    }
}