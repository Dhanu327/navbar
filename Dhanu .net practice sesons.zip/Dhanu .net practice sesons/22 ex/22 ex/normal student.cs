﻿//StudetClass.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSConcept
{
    abstract class StudentClass
    {
        private static int studentid;

        //static constructor
        static StudentClass()
        {
            //Console.WriteLine("Static Constructor");
            studentid = 10;
        }
        //Constructor
        public StudentClass()
        {
            //Console.WriteLine("Non-Static 0 args Constructor");
            studentid++;
            StudentID = studentid;
        }
        public StudentClass(string name, string email, int age, string examName, string boardName, int yearOfPassing) : this()
        {
            //Console.WriteLine("Non-Static 3 args Constructor");
            Name = name;
            Email = email;
            Age = age;
            LastQualification = new Qualification() { ExamName = examName, BoardName = boardName, YearOfPassing = yearOfPassing };
        }

        public int StudentID { get; set; }

        private string name;
        public string Name
        {
            set
            {
                if (value.Length > 0)
                    name = value;
                else
                    name = "Name is required";
            }
            get
            {
                return name;
            }
        }

        public string Email { set; get; }

        //between 18 and 70
        //Data Hiding 
        private int age;

        //Data Encapsulation
        //Property Procedures
        public int Age
        {
            set
            {
                if (value >= 18 && value <= 70)
                    age = value;
                else
                    age = -1;
            }
            get
            {
                return age;
            }
        }

        public Qualification LastQualification { set; get; }

        public virtual double Fees()
        {
            return 1000;
        }
        public abstract string StudentType();

    }



}