﻿//Program.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace OOPSConcept
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentClass s = null;
            string ans = "y";
            do
            {
                //Console.WriteLine("1.Normal Student");
                Console.WriteLine("1.Day Student");
                Console.WriteLine("2.Resident Student");
                Console.Write("Enter Your Choice:");
                Console.WriteLine("\n");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        s = CreateStudent("D");
                        break;
                    case 2:
                        s = CreateStudent("R");
                        break;

                    //case 3:
                    //    s = CreateStudent("R");
                    //    break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                }
                if (s != null)
                {
                    //CreateStudent();
                    DisplayStudent(s);

                }


                Console.Write("do you want to continue(y/n)?");
                ans = Console.ReadLine();
            } while (ans == "y");

        }
        static StudentClass CreateStudent(string type)
        {
            string name;
            string email;
            int age;
            string examName;
            string boardName;
            int yearOfPassing;
            Console.Write("Enter Your Name : ");
            name = Console.ReadLine();
            Console.Write("Enter Your Email : ");
            email = Console.ReadLine();
            Console.Write("Enter your Age : ");
            age = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter your Last Exam Name : ");
            examName = Console.ReadLine();
            Console.Write("Enter your Board Name : ");
            boardName = Console.ReadLine();
            Console.Write("Enter your Year of Passing : ");
            yearOfPassing = Convert.ToInt32(Console.ReadLine());
            StudentClass s = null;
            switch (type)
            {
                case "N":
                    //s = new StudentClass(name, email, age);
                    break;
                case "D":
                    Console.Write("Enter Your Locker Number : ");
                    string lockerno = Console.ReadLine();
                    s = new DStudent(name, email, age, lockerno, examName, boardName, yearOfPassing);
                    break;
                case "R":
                    Console.Write("Enter your Hostel Number : ");
                    string hostel = Console.ReadLine();
                    Console.Write("Enter Your Room Number : ");
                    string roomno = Console.ReadLine();
                    s = new RStudent(name, email, age, hostel, roomno, examName, boardName, yearOfPassing);
                    break;
            }
            return s;

        }

        static void DisplayStudent(StudentClass s)
        {
            Console.WriteLine("******************************");
            Console.WriteLine("ID : {0}", s.StudentID);
            Console.WriteLine("Name : {0}", s.Name);
            Console.WriteLine("Email : {0}", s.Email);
            Console.WriteLine("Fees : {0}", s.Fees());
            Console.WriteLine("Type : {0}", s.StudentType());
            Console.WriteLine("Last Qualification.......");
            Console.WriteLine("Exam Name : {0}", s.LastQualification.ExamName);
            Console.WriteLine("Board Name : {0}", s.LastQualification.BoardName);
            Console.WriteLine("Year OF Passing : {0}", s.LastQualification.YearOfPassing);


            if (s.Age == -1)
                Console.WriteLine("Invalid Age");
            else
                Console.WriteLine("Age : {0}", s.Age);





            if (s is DStudent)
            {
                Console.WriteLine("LockerNo : {0}", ((DStudent)s).LockerNo);

            }

            else if (s is RStudent)
            {
                Console.WriteLine("Hostel : {0}", ((RStudent)s).Hostel);
                Console.WriteLine("RoomNo : {0}", ((RStudent)s).RoomNo);



            }

            Console.WriteLine("******************************");
        }




    }
}