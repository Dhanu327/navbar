﻿//RStudent.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSConcept
{

    class RStudent : StudentClass
    {
        public RStudent(string name, string email, int age, string hostel, string roomno, string examName, string boardName, int yearOfPassing) : base(name, email, age, examName, boardName, yearOfPassing)
        {
            Hostel = hostel;
            RoomNo = roomno;
        }
        public string Hostel { get; set; }
        public string RoomNo { get; set; }
        public override double Fees()
        {
            return base.Fees() + 800;
        }
        public override string StudentType()
        {
            return "RStudent";
        }
    }
}