﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstConsole
{
    class AnimalConsole
    {
        static void Main(string[] args)
        {
            ILandAnimal landAnimal = null;
            IAirAnimal airAnimal = null;
            //    IWaterAnimal waterAnimal = null;
            string ans = "y";
            do
            {
                Console.WriteLine("Choose Animal of your Choice");
                Console.WriteLine("1.LandAnimal");
                Console.WriteLine("2.AirAnimal");
                Console.WriteLine("3.WaterAnimal");
                Console.Write("Enter Your Choice:");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:

                        Console.WriteLine("1.Dog");
                        Console.WriteLine("2.Cat");
                        Console.WriteLine("3.Bird");
                        Console.Write("Enter Your Choice:");
                        choice = int.Parse(Console.ReadLine());
                        switch (choice)
                        {
                            case 1:
                                landAnimal = new Dog("Alsatian");
                                break;
                            case 2:
                                landAnimal = new Cat("Cat");
                                break;
                            case 3:
                                landAnimal = new Bird("Pigeon");
                                break;

                        }
                        DisplayLand(landAnimal);
                        break;
                    case 2:
                        Console.WriteLine("1.Bird");
                        Console.Write("Enter Your Choice:");
                        choice = int.Parse(Console.ReadLine());
                        switch (choice)
                        {
                            case 1:
                                airAnimal = new Bird("Sparrow");
                                break;


                        }
                        DisplayAir(airAnimal);
                        break;
                    case 3:

                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                }

                Console.Write("do you want to continue(y/n)?");
                ans = Console.ReadLine();
            } while (ans == "y");
            // Console.ReadLine();
        }
        static void Display(IAnimal a)
        {
            Console.WriteLine("******************************");
            Console.WriteLine("Name:{0}", a.Name);
            Console.WriteLine("Voice:{0}", a.Voice());
            Console.WriteLine("Food:{0}", a.Food());
            Console.WriteLine("Shelter:{0}", a.Shelter());


            Console.WriteLine("******************************");


        }
        static void DisplayLand(ILandAnimal a)
        {
            Display(a);
            Console.WriteLine("Legs:{0}", a.Legs());
            Console.WriteLine("Speed:{0}", a.RSpeed());
        }
        static void DisplayAir(IAirAnimal a)
        {
            Display(a);
            Console.WriteLine("Wings:{0}", a.Wings());
            Console.WriteLine("Speed:{0}", a.FSpeed());
        }
    }
}