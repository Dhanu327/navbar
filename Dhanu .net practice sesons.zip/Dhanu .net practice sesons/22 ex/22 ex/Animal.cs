﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstConsole
{
    interface IAnimal
    {
        string Name { get; set; }
        string Voice();
        string Food();
        string Shelter();




    }
}