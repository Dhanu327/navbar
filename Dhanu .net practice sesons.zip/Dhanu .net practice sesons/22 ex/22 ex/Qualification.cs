﻿//Qualification.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSConcept
{
    class Qualification
    {
        public string ExamName { get; set; }
        public string BoardName { get; set; }
        public int YearOfPassing { set; get; }
    }
}
