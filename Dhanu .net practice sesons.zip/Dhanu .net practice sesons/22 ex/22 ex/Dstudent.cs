﻿//DStudent.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSConcept
{
    class DStudent : StudentClass
    {
        public DStudent(string name, string email, int age, string lockerno, string examName, string boardName, int yearOfPassing) : base(name, email, age, examName, boardName, yearOfPassing)
        {
            LockerNo = lockerno;
        }
        public string LockerNo { get; set; }
        public override double Fees()
        {
            return base.Fees() + 200;
        }
        public override string StudentType()
        {
            return "DStudent";
        }
    }
}