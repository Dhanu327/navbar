﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodApp.Models
{
    public class Menu
    {
        public int ItemId { get; set; }
        public string Item { get; set; }
    }
}
